package com.mile1_case_study.ecxeption;

public class NullNameException extends Exception {
	@Override
	public String toString() {
		return "NullNameException occurred";
	}
}
