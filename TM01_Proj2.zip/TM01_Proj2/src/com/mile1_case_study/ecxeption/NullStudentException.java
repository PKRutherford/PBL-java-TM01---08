package com.mile1_case_study.ecxeption;

public class NullStudentException extends Exception {
	@Override
	public String toString() {
		return "NullStudentException occurred";
	}
}