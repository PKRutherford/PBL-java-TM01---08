package com.mile1_case_study.ecxeption;

public class NullMarksArrayException extends Exception{
	@Override
	public String toString() {
		return "NullMarksArrayException occurred";
	}
}
